
CREATE TABLE Department (
                DeptName VARCHAR2(50) NOT NULL,
                DeptNumber VARCHAR2(10) NOT NULL,
                PhoneNumber VARCHAR2(12) NOT NULL,
                CONSTRAINT DEPARTMENT_PK PRIMARY KEY (DeptName)
);


CREATE TABLE CSUStaff (
                StaffID VARCHAR2(10) NOT NULL,
                FName VARCHAR2(20) NOT NULL,
                LName VARCHAR2(20) NOT NULL,
                MName VARCHAR2(20),
                PhoneNumber VARCHAR2(10),
                Email VARCHAR2(30) NOT NULL,
                position VARCHAR2(20) NOT NULL,
                StaffUserName VARCHAR2(20) NOT NULL,
                StaffPassword VARCHAR2(20) NOT NULL,
                DeptName VARCHAR2(50) NOT NULL,
                CONSTRAINT CSUSTAFF_PK PRIMARY KEY (StaffID)
);


CREATE TABLE Advisor (
                AdvisorID VARCHAR2(10) NOT NULL,
                OfficeNumber VARCHAR2(10) NOT NULL,
                BuildingNumber VARCHAR2(10) NOT NULL,
                CONSTRAINT ADVISOR_PK PRIMARY KEY (AdvisorID)
);


CREATE TABLE Address (
                Street VARCHAR2(20) NOT NULL,
                City VARCHAR2(20) NOT NULL,
                State VARCHAR2(20) NOT NULL,
                ZipCode VARCHAR2(10) NOT NULL,
                CONSTRAINT ADDRESS_PK PRIMARY KEY (Street)
);


CREATE TABLE Company (
                CompanyName VARCHAR2(100) NOT NULL,
                CEmail VARCHAR2(20) NOT NULL,
                CPhone VARCHAR2(12) NOT NULL,
                CLoginName VARCHAR2(20) NOT NULL,
                CPassword VARCHAR2(20) NOT NULL,
                Street VARCHAR2(20) NOT NULL,
                CONSTRAINT COMPANY_PK PRIMARY KEY (CompanyName)
);


CREATE UNIQUE INDEX Company_idx
 ON Company
 ( CEmail );

CREATE TABLE Assistant (
                AssistantID VARCHAR2(15) NOT NULL,
                FirstN VARCHAR2(20) NOT NULL,
                LastN VARCHAR2(20) NOT NULL,
                Phone VARCHAR2(12) NOT NULL,
                Email VARCHAR2(30) NOT NULL,
                CompanyName VARCHAR2(100) NOT NULL,
                CONSTRAINT ASSISTANT_PK PRIMARY KEY (AssistantID)
);


CREATE TABLE Mentor (
                MentorID VARCHAR2(10) NOT NULL,
                Start_Date VARCHAR2(15) NOT NULL,
                End_Date VARCHAR2(15) NOT NULL,
                CONSTRAINT MENTOR_PK PRIMARY KEY (MentorID)
);


CREATE TABLE Project (
                ProjectNumber VARCHAR2(10) NOT NULL,
                Ptitle VARCHAR2(20) NOT NULL,
                Type VARCHAR2(50) NOT NULL,
                Industry VARCHAR2(50) NOT NULL,
                Deliverable VARCHAR2(500) NOT NULL,
                TeamNumber NUMBER NOT NULL,
                ProjectStatus VARCHAR2(10) NOT NULL,
                AdvisorID VARCHAR2(10) NOT NULL,
                MentorID VARCHAR2(10) NOT NULL,
                CompanyName VARCHAR2(100) NOT NULL,
                CONSTRAINT PROJECT_PK PRIMARY KEY (ProjectNumber)
);
COMMENT ON COLUMN Project.ProjectStatus IS 'Complete or not';


CREATE TABLE ProposalStatus (
                CompanyName VARCHAR2(100) NOT NULL,
                ProjectNumber VARCHAR2(10) NOT NULL,
                Status VARCHAR2(15) NOT NULL,
                CONSTRAINT PROPOSALSTATUS_PK PRIMARY KEY (CompanyName, ProjectNumber)
);


CREATE TABLE Requirement (
                CompanyName VARCHAR2(100) NOT NULL,
                ProjectNumber VARCHAR2(10) NOT NULL,
                NumberofStudent NUMBER NOT NULL,
                Major VARCHAR2(30) NOT NULL,
                AcademicYear VARCHAR2(10) NOT NULL,
                Discipline VARCHAR2(50) NOT NULL,
                Other VARCHAR2(100) NOT NULL,
                CONSTRAINT REQUIREMENT_PK PRIMARY KEY (CompanyName, ProjectNumber)
);


CREATE TABLE ProCategory (
                ProjectNumber VARCHAR2(10) NOT NULL,
                Type VARCHAR2(30) NOT NULL,
                Description VARCHAR2(500) NOT NULL,
                CONSTRAINT PROCATEGORY_PK PRIMARY KEY (ProjectNumber)
);


CREATE TABLE Issue (
                IssueID NUMBER NOT NULL,
                IssueType VARCHAR2(25) NOT NULL,
                Description VARCHAR2(500) NOT NULL,
                Status VARCHAR2(10) NOT NULL,
                MentorID VARCHAR2(10) NOT NULL,
                ProjectNumber VARCHAR2(10) NOT NULL,
                AssistantID VARCHAR2(15) NOT NULL,
                CONSTRAINT ISSUE_PK PRIMARY KEY (IssueID)
);
COMMENT ON COLUMN Issue.IssueType IS 'for ex:
Project problem
Techniqual problem
...';
COMMENT ON COLUMN Issue.Status IS 'solved - processing';


CREATE TABLE Group_1 (
                GroupNumber NUMBER NOT NULL,
                TeamSize NUMBER NOT NULL,
                MentorID VARCHAR2(10) NOT NULL,
                ProjectNumber VARCHAR2(10) NOT NULL,
                CONSTRAINT GROUP_1_PK PRIMARY KEY (GroupNumber)
);


CREATE TABLE CSUStudent (
                StudentID VARCHAR2(10) NOT NULL,
                FName VARCHAR2(50) NOT NULL,
                LName VARCHAR2(50) NOT NULL,
                MName VARCHAR2(50),
                PhoneNumber VARCHAR2(10),
                Email VARCHAR2(50) NOT NULL,
                requestStatus VARCHAR2(15) NOT NULL,
                StuUserName VARCHAR2(20) NOT NULL,
                StuPassword VARCHAR2(20) NOT NULL,
                GroupNumber NUMBER NOT NULL,
                DeptName VARCHAR2(50) NOT NULL,
                CONSTRAINT CSUSTUDENT_PK PRIMARY KEY (StudentID)
);
COMMENT ON COLUMN CSUStudent.requestStatus IS 'approved or waiting';


CREATE TABLE Major (
                StudentID VARCHAR2(10) NOT NULL,
                MajorName VARCHAR2(30) NOT NULL,
                ProjectNumber VARCHAR2(10) NOT NULL,
                DeptName VARCHAR2(50) NOT NULL,
                CONSTRAINT MAJOR_PK PRIMARY KEY (StudentID)
);


CREATE TABLE StudentPublicProfile (
                StudentID VARCHAR2(10) NOT NULL,
                AcademicYear VARCHAR2(15) NOT NULL,
                Skills VARCHAR2(500) NOT NULL,
                Experience VARCHAR2(500) NOT NULL,
                Status VARCHAR2(15) NOT NULL,
                CONSTRAINT STUDENTPUBLICPROFILE_PK PRIMARY KEY (StudentID)
);
COMMENT ON COLUMN StudentPublicProfile.Status IS 'In team or not';


CREATE TABLE WorkHours (
                StudentID VARCHAR2(10) NOT NULL,
                Hours VARCHAR2(10) NOT NULL,
                Start_Date VARCHAR2(10) NOT NULL,
                End_Date VARCHAR2(10) NOT NULL,
                ProjectNumber VARCHAR2(10) NOT NULL,
                CONSTRAINT WORKHOURS_PK PRIMARY KEY (StudentID)
);


ALTER TABLE CSUStaff ADD CONSTRAINT DEPARTMENT_CSUSTAFF_FK
FOREIGN KEY (DeptName)
REFERENCES Department (DeptName)
NOT DEFERRABLE;

ALTER TABLE Student ADD CONSTRAINT DEPARTMENT_STUDENT_FK
FOREIGN KEY (DeptName)
REFERENCES Department (DeptName)
NOT DEFERRABLE;

ALTER TABLE Major ADD CONSTRAINT DEPARTMENT_MAJOR_FK
FOREIGN KEY (DeptName)
REFERENCES Department (DeptName)
NOT DEFERRABLE;

ALTER TABLE Advisor ADD CONSTRAINT CSUSTAFF_ADVISOR_FK
FOREIGN KEY (AdvisorID)
REFERENCES CSUStaff (StaffID)
NOT DEFERRABLE;

ALTER TABLE Mentor ADD CONSTRAINT CSUSTAFF_MENTOR_FK
FOREIGN KEY (MentorID)
REFERENCES CSUStaff (StaffID)
NOT DEFERRABLE;

ALTER TABLE Project ADD CONSTRAINT ADVISOR_PROPOSAL_FK
FOREIGN KEY (AdvisorID)
REFERENCES Advisor (AdvisorID)
NOT DEFERRABLE;

ALTER TABLE Company ADD CONSTRAINT ADDRESS_COMPANY_FK
FOREIGN KEY (Street)
REFERENCES Address (Street)
NOT DEFERRABLE;

ALTER TABLE Assistant ADD CONSTRAINT COMPANY_ASSISTANT_FK
FOREIGN KEY (CompanyName)
REFERENCES Company (CompanyName)
NOT DEFERRABLE;

ALTER TABLE Requirement ADD CONSTRAINT COMPANY_REQUIREMENT_FK
FOREIGN KEY (CompanyName)
REFERENCES Company (CompanyName)
NOT DEFERRABLE;

ALTER TABLE Project ADD CONSTRAINT COMPANY_PROJECT_FK
FOREIGN KEY (CompanyName)
REFERENCES Company (CompanyName)
NOT DEFERRABLE;

ALTER TABLE ProposalStatus ADD CONSTRAINT COMPANY_PROJECTSTATUS_FK
FOREIGN KEY (CompanyName)
REFERENCES Company (CompanyName)
NOT DEFERRABLE;

ALTER TABLE Issue ADD CONSTRAINT ASSISTANT_ISSUE_FK
FOREIGN KEY (AssistantID)
REFERENCES Assistant (AssistantID)
NOT DEFERRABLE;

ALTER TABLE Group_1 ADD CONSTRAINT MENTOR_GROUP_FK
FOREIGN KEY (MentorID)
REFERENCES Mentor (MentorID)
NOT DEFERRABLE;

ALTER TABLE Issue ADD CONSTRAINT MENTOR_ISSUE_FK
FOREIGN KEY (MentorID)
REFERENCES Mentor (MentorID)
NOT DEFERRABLE;

ALTER TABLE Project ADD CONSTRAINT MENTOR_PROJECT_FK
FOREIGN KEY (MentorID)
REFERENCES Mentor (MentorID)
NOT DEFERRABLE;

ALTER TABLE WorkHours ADD CONSTRAINT PROPOSAL_WORKHOURS_FK
FOREIGN KEY (ProjectNumber)
REFERENCES Project (ProjectNumber)
NOT DEFERRABLE;

ALTER TABLE Group_1 ADD CONSTRAINT PROPOSAL_GROUP_1_FK
FOREIGN KEY (ProjectNumber)
REFERENCES Project (ProjectNumber)
NOT DEFERRABLE;

ALTER TABLE Major ADD CONSTRAINT PROPOSAL_MAJOR_FK
FOREIGN KEY (ProjectNumber)
REFERENCES Project (ProjectNumber)
NOT DEFERRABLE;

ALTER TABLE Issue ADD CONSTRAINT PROJECT_ISSUE_FK
FOREIGN KEY (ProjectNumber)
REFERENCES Project (ProjectNumber)
NOT DEFERRABLE;

ALTER TABLE ProCategory ADD CONSTRAINT PROJECT_PROCATEGORY_FK
FOREIGN KEY (ProjectNumber)
REFERENCES Project (ProjectNumber)
NOT DEFERRABLE;

ALTER TABLE Requirement ADD CONSTRAINT PROJECT_REQUIREMENT_FK
FOREIGN KEY (ProjectNumber)
REFERENCES Project (ProjectNumber)
NOT DEFERRABLE;

ALTER TABLE ProposalStatus ADD CONSTRAINT PROJECT_PROJECTSTATUS_FK
FOREIGN KEY (ProjectNumber)
REFERENCES Project (ProjectNumber)
NOT DEFERRABLE;

ALTER TABLE Student ADD CONSTRAINT STUDENT_GROUP_FK
FOREIGN KEY (GroupNumber)
REFERENCES Group_1 (GroupNumber)
NOT DEFERRABLE;

ALTER TABLE WorkHours ADD CONSTRAINT STUDENT_STUDENTHOURS_FK
FOREIGN KEY (StudentID)
REFERENCES Student (StudentID)
NOT DEFERRABLE;

ALTER TABLE StudentPublicProfile ADD CONSTRAINT STUDENT_STUDENTPUBLICPROFIL459
FOREIGN KEY (StudentID)
REFERENCES Student (StudentID)
NOT DEFERRABLE;

ALTER TABLE Major ADD CONSTRAINT STUDENT_MAJOR_FK
FOREIGN KEY (StudentID)
REFERENCES Student (StudentID)
NOT DEFERRABLE;