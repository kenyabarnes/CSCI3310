--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.CSUSTAFF
SET DEFINE OFF;
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1005001234','Alex','Borg','A','4075115689','AlexB@clayton.edu','Graduated Student','AlexB','567A','Science');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1005003456','James','Ball','L','7076518489','JameB@clayton.edu','Graduated Student','JameB','BC12','Health');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1008001235','Evan','Zell','O','5074419889','EvanZ@clayton.edu','Professor','dcba','4321','Science');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1008001236','Joyce','Vile','Q','4088717089','JoyceV@clayton.edu','Professor','JoyceV','874K','Health');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1008005478','Kim','Bays','R','4097710189','KimB@clayton.edu','Professor','KimB','AS12','Business');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1005102345','John','Chase','Y','6077815749','JohnC@clayton.edu','Graduated Students','zywx','9876','Business');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1005894123','James','Nguyen','B','4047105544','nguyenJ@clayton.edu','Professor','JaNB','145aJ','Business');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1006782201','John','Will','N','4040145834','willJ@clayton.edu','Graduated Student','Jwill','130kL','Science');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1005895210','Ann','Jones','V','4045016958','jonesA@clayton.edu','Professor','AnnJ','12345','Science');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1007450178','Emily','April','K','4046411728','aprilE@clayton.edu','Professor','Apr78','56789','Health');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1004625714','Jean','May','Q','4046899821','mayJ@clayton.edu','Graduated Student','hqow','785rt','Health');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('200','John','Smith','Phil','2000000000','jps@gg.com','professor','jps','NoneofUrBusiness','Math');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('201','Will','Smith','Johnathan','2000000001','wjs@gg.com','professor','wjs','DailyApple','English');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('202','Bill','Nye','DaScienceGuy','2000000003','bn@gg.com','professor','bn','ScienceRules','Art');
Insert into BLUU.CSUSTAFF (STAFFID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,POSITION,STAFFUSERNAME,STAFFPASSWORD,DEPTNAME) values ('1008001508','Mary','Lee','W','4075641238','maryL@clayton.edu','Professor','MaryL','ht145','Health');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.CSUSTUDENT
SET DEFINE OFF;
Insert into BLUU.CSUSTUDENT (STUDENTID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,REQUESTSTATUS,STUUSERNAME,STUPASSWORD,GROUPNUMBER,DEPTNAME) values ('1004001568','Tim','Jane','Q','4041239874','JaneT@student.clayton.edu','Approved','tim8','123A',0,'Health');
Insert into BLUU.CSUSTUDENT (STUDENTID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,REQUESTSTATUS,STUUSERNAME,STUPASSWORD,GROUPNUMBER,DEPTNAME) values ('1002456987','Ann','Walk','A','3401248945','annL@student.clayton.edu','Approved','ann6','aw12',0,'Science');
Insert into BLUU.CSUSTUDENT (STUDENTID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,REQUESTSTATUS,STUUSERNAME,STUPASSWORD,GROUPNUMBER,DEPTNAME) values ('2011','Eric','Red','The','2344432332','ericred@gmail.com','Active','EricViking','AThingAThing',2001,'Science');
Insert into BLUU.CSUSTUDENT (STUDENTID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,REQUESTSTATUS,STUUSERNAME,STUPASSWORD,GROUPNUMBER,DEPTNAME) values ('1004005897','Bob','Lee','T','1014856789','LeeB@student.clayton.edu','Applied','LeeB','154Y',0,'Science');
Insert into BLUU.CSUSTUDENT (STUDENTID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,REQUESTSTATUS,STUUSERNAME,STUPASSWORD,GROUPNUMBER,DEPTNAME) values ('1004000029','Boa','Mile','Z','4012013011','MileB@student.clayton.edu','Applied','MileB','143Po',0,'Health');
Insert into BLUU.CSUSTUDENT (STUDENTID,FNAME,LNAME,MNAME,PHONENUMBER,EMAIL,REQUESTSTATUS,STUUSERNAME,STUPASSWORD,GROUPNUMBER,DEPTNAME) values ('1005326987','Hello','John','K','4047510001','johnH@student.clayton.edu','Applied','johnH','098p',0,'Business');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.DEPARTMENT
SET DEFINE OFF;
Insert into BLUU.DEPARTMENT (DEPTNAME,DEPTNUMBER,PHONENUMBER) values ('Health','189','112-101-2222');
Insert into BLUU.DEPARTMENT (DEPTNAME,DEPTNUMBER,PHONENUMBER) values ('Business','134','123-404-2298');
Insert into BLUU.DEPARTMENT (DEPTNAME,DEPTNUMBER,PHONENUMBER) values ('Science','167','182-154-4782');
Insert into BLUU.DEPARTMENT (DEPTNAME,DEPTNUMBER,PHONENUMBER) values ('Math','201','6784660000');
Insert into BLUU.DEPARTMENT (DEPTNAME,DEPTNUMBER,PHONENUMBER) values ('English','202','6784660001');
Insert into BLUU.DEPARTMENT (DEPTNAME,DEPTNUMBER,PHONENUMBER) values ('Art','203','6784660002');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.GROUP_1
SET DEFINE OFF;
Insert into BLUU.GROUP_1 (GROUPNUMBER,TEAMSIZE,MENTORID,PROJECTNUMBER) values (2001,4,'201','000');
Insert into BLUU.GROUP_1 (GROUPNUMBER,TEAMSIZE,MENTORID,PROJECTNUMBER) values (1,3,'1004625714','102');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.ISSUE
SET DEFINE OFF;
Insert into BLUU.ISSUE (ISSUEID,ISSUETYPE,DESCRIPTION,STATUS,MENTORID,PROJECTNUMBER,ASSISTANTID) values (0,'bug','student cannot login','Resolved','201','000','232');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.ASSISTANT
SET DEFINE OFF;
Insert into BLUU.ASSISTANT (ASSISTANTID,FIRSTN,LASTN,PHONE,EMAIL,COMPANYNAME) values ('232','Elizabeth','Comstock','2332342342','elizastock@biorift.com','Hershey');
Insert into BLUU.ASSISTANT (ASSISTANTID,FIRSTN,LASTN,PHONE,EMAIL,COMPANYNAME) values ('100589','Rose','June','6781012011','June_6@gmail.com','ABC');
Insert into BLUU.ASSISTANT (ASSISTANTID,FIRSTN,LASTN,PHONE,EMAIL,COMPANYNAME) values ('101471','Day','Light','4041092011','June_6@gmail.com','DEF');
Insert into BLUU.ASSISTANT (ASSISTANTID,FIRSTN,LASTN,PHONE,EMAIL,COMPANYNAME) values ('102568','Dark','Moon','6785012014','June_6@gmail.com','GHI');
Insert into BLUU.ASSISTANT (ASSISTANTID,FIRSTN,LASTN,PHONE,EMAIL,COMPANYNAME) values ('103897','Wind','June','6781071234','June_6@gmail.com','JKL');
Insert into BLUU.ASSISTANT (ASSISTANTID,FIRSTN,LASTN,PHONE,EMAIL,COMPANYNAME) values ('104782','Drew','August','6795478011','June_6@gmail.com','MNO');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.ADVISOR
SET DEFINE OFF;
Insert into BLUU.ADVISOR (ADVISORID,OFFICENUMBER,BUILDINGNUMBER) values ('1008001235','320','167');
Insert into BLUU.ADVISOR (ADVISORID,OFFICENUMBER,BUILDINGNUMBER) values ('1008005478','214','134');
Insert into BLUU.ADVISOR (ADVISORID,OFFICENUMBER,BUILDINGNUMBER) values ('200','222','289');
Insert into BLUU.ADVISOR (ADVISORID,OFFICENUMBER,BUILDINGNUMBER) values ('1008001508','111','189');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.ADDRESS
SET DEFINE OFF;
Insert into BLUU.ADDRESS (STREET,CITY,STATE,ZIPCODE) values ('123 Fake Street','Springfold','MA','20000');
Insert into BLUU.ADDRESS (STREET,CITY,STATE,ZIPCODE) values ('189 Mon','Jan','Spring','10234');
Insert into BLUU.ADDRESS (STREET,CITY,STATE,ZIPCODE) values ('291 Tue','Feb','Spring','10234');
Insert into BLUU.ADDRESS (STREET,CITY,STATE,ZIPCODE) values ('312 Wed','Mar','Summer','10657');
Insert into BLUU.ADDRESS (STREET,CITY,STATE,ZIPCODE) values ('423 Thu','Apr','Fall','12897');
Insert into BLUU.ADDRESS (STREET,CITY,STATE,ZIPCODE) values ('534 Fri','Jan','Winter','19567');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.MAJOR
SET DEFINE OFF;
Insert into BLUU.MAJOR (STUDENTID,MAJORNAME,PROJECTNUMBER,DEPTNAME) values ('2011','Cooking','000','Health');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.MENTOR
SET DEFINE OFF;
Insert into BLUU.MENTOR (MENTORID,START_DATE,END_DATE) values ('1005894123','08/30/2017','ongoing');
Insert into BLUU.MENTOR (MENTORID,START_DATE,END_DATE) values ('1005895210','11/01/2017','Ongoing');
Insert into BLUU.MENTOR (MENTORID,START_DATE,END_DATE) values ('1004625714','05/30/2017','Ongoing');
Insert into BLUU.MENTOR (MENTORID,START_DATE,END_DATE) values ('1008001235','02/30/2017','ongoing');
Insert into BLUU.MENTOR (MENTORID,START_DATE,END_DATE) values ('201','244','288');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.PROCATEGORY
SET DEFINE OFF;
Insert into BLUU.PROCATEGORY (PROJECTNUMBER,TYPE,DESCRIPTION) values ('000','cooking','Help make chocolate');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.PROJECT
SET DEFINE OFF;
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('201','Testing','Design','Health','Essay',18,'Approved','1008001508','1004625714','JKL');
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('110','New Chemical','Research','Science','Power Point',9,'Approved','1008001235','1005895210','MNO');
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('112','New Insect','Research','Science','PDF',10,'Approved','1008001235','1005895210','GHI');
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('115','Computer','Documents','Health','Documents',3,'Aprroved','1008001508','1004625714','JKL');
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('000','Make Chocolate','Cooking','Business','Chocolate',3,'Active','200','201','Hershey');
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('102','Fast Reservation','Web App','Health','ISO',1,'Ongoing','1008001508','1004625714','DEF');
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('107','Web Reservation','Web Mobile App','Health','ISO',8,'Ongoing','1008001508','1004625714','JKL');
Insert into BLUU.PROJECT (PROJECTNUMBER,PTITLE,TYPE,INDUSTRY,DELIVERABLE,TEAMNUMBER,PROJECTSTATUS,ADVISORID,MENTORID,COMPANYNAME) values ('101','Fast Reservation','Mobile Application','Health','ISO and Android',3,'Ongoing','1008001508','1004625714','ABC');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.PROPOSALSTATUS
SET DEFINE OFF;
Insert into BLUU.PROPOSALSTATUS (COMPANYNAME,PROJECTNUMBER,STATUS) values ('Hershey','000','Active');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.REQUIREMENT
SET DEFINE OFF;
Insert into BLUU.REQUIREMENT (COMPANYNAME,PROJECTNUMBER,NUMBEROFSTUDENT,MAJOR,ACADEMICYEAR,DISCIPLINE,OTHER) values ('Hershey','000',4,'Health','2017','Health','Cooking');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.STUDENTPUBLICPROFILE
SET DEFINE OFF;
Insert into BLUU.STUDENTPUBLICPROFILE (STUDENTID,ACADEMICYEAR,SKILLS,EXPERIENCE,STATUS) values ('1004005897','2017','Microsoft','No','Applied');
Insert into BLUU.STUDENTPUBLICPROFILE (STUDENTID,ACADEMICYEAR,SKILLS,EXPERIENCE,STATUS) values ('1004001568','2016','Power Point','No','Applied');
Insert into BLUU.STUDENTPUBLICPROFILE (STUDENTID,ACADEMICYEAR,SKILLS,EXPERIENCE,STATUS) values ('2011','2017','Cooking','4 years','Active');
--------------------------------------------------------
--  File created - Wednesday-November-29-2017   
--------------------------------------------------------
REM INSERTING into BLUU.WORKHOURS
SET DEFINE OFF;
Insert into BLUU.WORKHOURS (STUDENTID,HOURS,START_DATE,END_DATE,PROJECTNUMBER) values ('2011','39','12-13-17','12-24-17','000');
