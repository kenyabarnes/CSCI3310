/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.sql.*;
import java.util.*;
import util.OracleConnection;

/**
 *
 * @author uuvin
 */
public class Project implements Serializable {
    
    
    private String projectNumber;
    private String pTitle;
    private String type;
    private String industry;
    private String deliverables;
    private int teamNumber;
    private String projectStatus;
    private String advisorID;
    private String mentorID;
    private String companyName;
    private String description;
    private String proposalStatus;
    
    Connection conn = null;

    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public String getpTitle() {
        return pTitle;
    }

    public void setpTitle(String pTitle) {
        this.pTitle = pTitle;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getDeliverables() {
        return deliverables;
    }

    public void setDeliverables(String deliverables) {
        this.deliverables = deliverables;
    }

    public int getTeamNumber() {
        return teamNumber;
    }

    public void setTeamNumber(int teamNumber) {
        this.teamNumber = teamNumber;
    }

    public String getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(String projectStatus) {
        this.projectStatus = projectStatus;
    }

    public String getAdvisorID() {
        return advisorID;
    }

    public void setAdvisorID(String advisorID) {
        this.advisorID = advisorID;
    }

    public String getMentorID() {
        return mentorID;
    }

    public void setMentorID(String mentorID) {
        this.mentorID = mentorID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProposalStatus() {
        return proposalStatus;
    }

    public void setProposalStatus(String proposalStatus) {
        this.proposalStatus = proposalStatus;
    }

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }

    
    
    public void setAdvisor(String advisorID) {
        
        try{
            conn = OracleConnection.getConnection();
            Statement stmt = conn.createStatement();
            String sql = "select email from csustaff where staffid = " + advisorID;
            ResultSet rs = stmt.executeQuery(sql);
            this.advisorID = rs.getString("Email");
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            OracleConnection.closeConnection();
        }
        
    }
    
    public void setMentor(String mentorID) {
        
        try{
            conn = OracleConnection.getConnection();
            Statement stmt = conn.createStatement();
            String sql = "select email from csustaff where staffid = " + mentorID;
            ResultSet rs = stmt.executeQuery(sql);
            this.mentorID = rs.getString("Email");
            
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            OracleConnection.closeConnection();
        }
        
    }
    
   
    
    public List<Project> getApproved(){
        List<Project> projects = new ArrayList<Project>();
        try{
            conn = OracleConnection.getConnection();
            Statement stmt = conn.createStatement();
            String sql = "select * from project where projectStatus = 'Approved'"; 
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                Project proj = new Project();
                proj.setProjectNumber(rs.getString(1));
                proj.setpTitle (rs.getString(2));
                proj.setType (rs.getString(3));
                proj.setIndustry (rs.getString(4));
                proj.setDeliverables(rs.getString(5));
                proj.setTeamNumber(rs.getInt(6));
                proj.setProjectStatus(rs.getString(7));
                proj.setAdvisorID(rs.getString(8));
                proj.setMentorID(rs.getString(9));
                proj.setCompanyName(rs.getString(10));
                projects.add(proj);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            OracleConnection.closeConnection();
        }
        
        return projects;
    }
}
