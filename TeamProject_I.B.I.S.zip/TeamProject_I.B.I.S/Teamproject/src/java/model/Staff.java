/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.sql.*;
import java.util.*;
import util.OracleConnection;

/**
 *
 * @author Bao Luu
 */
public class Staff implements Serializable {
    private String StaffID;// VARCHAR2(10) NOT NULL,
    private String FName; //VARCHAR2(50) NOT NULL,
    private String LName; //VARCHAR2(50) NOT NULL,
    private String MName; //VARCHAR2(50),
    private String Email; //VARCHAR2(50) NOT NULL,
    private String position;
    private String DeptName;
    private String PhoneNumber;
    private String Start_Date;
    private String End_Date;
    Connection conn = null;

    public String getDeptName() {
        return DeptName;
    }

    public void setDeptName(String DeptName) {
        this.DeptName = DeptName;
    }
    
   
    public String getStaffID() {
        return StaffID;
    }

    public void setStaffID(String StaffID) {
        this.StaffID = StaffID;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public String getMName() {
        return MName;
    }

    public void setMName(String MName) {
        this.MName = MName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Connection getConn() {
        return conn;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getStart_Date() {
        return Start_Date;
    }

    public void setStart_Date(String Start_Date) {
        this.Start_Date = Start_Date;
    }

    public String getEnd_Date() {
        return End_Date;
    }

    public void setEnd_Date(String End_Date) {
        this.End_Date = End_Date;
    }
    

    public void setConn(Connection conn) {
        this.conn = conn;
    }
    public List<Staff> getMentors (){
        List<Staff> staffs = new ArrayList<Staff>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
    String sql = "select LName, FName, email, position, DeptName, PhoneNumber, Start_Date, End_Date from Mentor inner join CSUStaff "
            + "on StaffID =  MentorID";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        Staff stf = new Staff();
        stf.setFName (rs.getString(1));
        stf.setLName (rs.getString(2));
        stf.setEmail(rs.getString(3));
        stf.setPosition (rs.getString(4));
        stf.setDeptName (rs.getString(5)); 
        stf.setPhoneNumber(rs.getString(6));
        stf.setStart_Date(rs.getString(7));
        stf.setEnd_Date(rs.getString(8));
        staffs.add(stf);
    }
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return staffs;       
    }
    public List<Staff> getAllStaffs (){
        List<Staff> staffs = new ArrayList<Staff>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
    String sql = "select * from CSUStaff where StaffID not in (Select AdvisorID from Advisor)";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        Staff stf = new Staff();
        stf.setFName (rs.getString(2));
        stf.setLName (rs.getString(3));
        stf.setEmail (rs.getString("Email"));
        stf.setPosition (rs.getString(7));
        stf.setDeptName(rs.getString("DeptName"));
        staffs.add(stf);
    }
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return staffs;       
    }
    
    @Override
    public String toString(){
        return "Staff :" + " "+ DeptName + " " + FName +" "+ Email;
    }
      // login - changing Password and UserName when do project
    public boolean ValidateStaff(String userN, String passW){
        boolean validated = false;
        try {
            conn = OracleConnection.getConnection();
            PreparedStatement ps
                    = conn.prepareStatement("SELECT * FROM CSUStaff WHERE staffUserName = ? and staffPassWord = ?");
            ps.setString(1,userN);
            ps.setString(2,passW);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){ // have correction combination email and phone
                validated = true;
            }
    }catch (Exception ex){
    ex.printStackTrace();} finally {
        OracleConnection.closeConnection();} 
        return validated;
    }
     public static void main(String[] args){
        Staff stf = new Staff();
        List<Staff> staffs = stf.getMentors();
        for (Staff s : staffs){
            System.out.println (s.toString());
        }
     }
    
}