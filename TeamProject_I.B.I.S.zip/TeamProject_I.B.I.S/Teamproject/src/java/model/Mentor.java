/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.*;
import java.sql.*;
import java.util.*;
import util.OracleConnection;

/**
 *
 * @author Bao Luu
 */
public class Mentor implements Serializable {
    private String FName;
    private String LName;
    private String Email;
    private String Start_Date;
    private String End_Date;
    private String MentorID;
    private String DeptName;
    private String PhoneNumber;
    private String position;
    Connection conn = null;
    
  public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public String getMentorID() {
        return MentorID;
    }

    public void setMentorID(String MentorID) {
        this.MentorID = MentorID;
    }

    public String getEnd_Date() {
        return End_Date;
    }

    public void setEnd_Date(String End_Date) {
        this.End_Date = End_Date;
    }

    public String getStart_Date() {
        return Start_Date;
    }

    public void setStart_Date(String Start_Date) {
        this.Start_Date = Start_Date;
    }
    
    

   /* public String getStaffID() {
        return StaffID;
    }

    public void setStaffID(String StaffID) {
        this.StaffID = StaffID;
    }*/

    public String getDeptName() {
        return DeptName;
    }

    public void setDeptName(String DeptName) {
        this.DeptName = DeptName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

   

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }
@Override
    public String toString(){
        return "Mentor :" + ""+ DeptName + "" + PhoneNumber;
    }
    public List<Mentor> getPMentors (){
        List<Mentor> mentors = new ArrayList<Mentor>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
     String sql = "select LName, FName, position, DeptName, PhoneNumber, Start_Date, End_Date from Mentor inner join CSUStaff "
            + "on StaffID =  MentorID and position = 'Professor'";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        Mentor mnt = new Mentor();
        mnt.setFName (rs.getString(1));
        mnt.setLName (rs.getString(2));
        mnt.setPosition (rs.getString(3));
        mnt.setDeptName (rs.getString(4)); 
        mnt.setPhoneNumber(rs.getString(5));
        mnt.setStart_Date(rs.getString(6));
         mnt.setEnd_Date(rs.getString(7));
        mentors.add(mnt);
    }   
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return mentors;       
    }
    
   public List<Mentor> getMentors (){
        List<Mentor> mentors = new ArrayList<Mentor>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
     String sql = "select LName, FName, position, DeptName, PhoneNumber, Start_Date, End_Date from Mentor inner join CSUStaff "
            + "on StaffID =  MentorID";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        Mentor mnt = new Mentor();
        mnt.setFName (rs.getString(1));
        mnt.setLName (rs.getString(2));
        mnt.setPosition (rs.getString(3));
        mnt.setDeptName (rs.getString(4)); 
        mnt.setPhoneNumber(rs.getString(5));
        mnt.setStart_Date(rs.getString(6));
         mnt.setEnd_Date(rs.getString(7));
        mentors.add(mnt);
    }   
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return mentors;       
    }
     // login - changing Password and UserName when do project
    public boolean ValidateMentor(String userN, String passW){
        boolean validated = false;
        try {
            conn = OracleConnection.getConnection();
            PreparedStatement ps
                    = conn.prepareStatement(
                    "SELECT * FROM CSUStaff inner join Mentor on StaffID = MentorID "
                            + "where staffUserName = ? and staffPassWord = ?");
            ps.setString(1,userN);
            ps.setString(2,passW);
            ResultSet rs = ps.executeQuery();
            if (rs.next()){ // have correction combination email and phone
                validated = true;
            }
    }catch (Exception ex){
    ex.printStackTrace();} finally {
        OracleConnection.closeConnection();} 
        return validated;
    }
    
    
    public static void main(String[] args){
        Mentor mnt = new Mentor();
        List<Mentor> mentors = mnt.getPMentors();
        for (Mentor s : mentors){
            System.out.println (s.toString());
        }
       
    }
}
