/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.*;
import java.sql.*;
import java.util.*;
import util.OracleConnection;

/**
 *
 * @author Kevin
 */
public class SetProposal implements Serializable {
  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    private String projectNumber;
    private String pTitle;
    private String type;
    private String industry;
    private String deliverables;
    private int teamNumber;
    private String projectStatus;
    private String advisorID;
    private String mentorID;
    private String companyName;
    private String description;
    private String proposalStatus;
    
    Connection conn = null;

    public String getProjectNumber() {
        return projectNumber;
    }

    public void setProjectNumber(String projectNumber) {
        this.projectNumber = projectNumber;
    }

    public String getpTitle() {
        return pTitle;
    }

    public void setpTitle(String pTitle) {
        this.pTitle = pTitle;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getDeliverables() {
        return deliverables;
    }

    public void setDeliverables(String deliverables) {
        this.deliverables = deliverables;
    }

    public int getTeamNumber() {
        return teamNumber;
    }

    public void setTeamNumber(int teamNumber) {
        this.teamNumber = teamNumber;
    }

    public String getProjectStatus() {
        return projectStatus;
    }

    public void setProjectStatus(String projectStatus) {
        this.projectStatus = projectStatus;
    }

    public String getAdvisorID() {
        return advisorID;
    }

    public void setAdvisorID(String advisorID) {
        this.advisorID = advisorID;
    }

    public String getMentorID() {
        return mentorID;
    }

    public void setMentorID(String mentorID) {
        this.mentorID = mentorID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProposalStatus() {
        return proposalStatus;
    }

    public void setProposalStatus(String proposalStatus) {
        this.proposalStatus = proposalStatus;
    }

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }
    
    public List<SetProposal> getProjects (){
        List<SetProposal> projectList = new ArrayList<SetProposal>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
    String sql = "select * from project";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        SetProposal stf = new SetProposal();
        stf.setProjectNumber (rs.getString(1));
        stf.setpTitle (rs.getString(2));
        stf.setType (rs.getString(3));
        stf.setIndustry (rs.getString(4));
        stf.setDeliverables(rs.getString(5));
        stf.setTeamNumber(rs.getInt(6));
        stf.setProjectStatus(rs.getString(7));
        stf.setAdvisorID(rs.getString(8));
        stf.setMentorID(rs.getString(9));
        stf.setCompanyName(rs.getString(10));
        projectList.add(stf);
    }
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return projectList;       
    }
    
    
    public int CreateProject(String projectNumber, String pTitle, String type, 
            String industry, String deliverables, int teamNumber, String projectStatus, String advisorID,
            String mentorID, String companyName ){
        int row =0;
        try{
            //get connection
            conn = OracleConnection.getConnection();
            //preparedStatment
            Statement statement = conn.createStatement();
            PreparedStatement ps;
            String sql = "insert into project values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);

            ps.setString(1, projectNumber);
            ps.setString(2, pTitle);
            ps.setString(3, type);
            ps.setString(4, industry);
            ps.setString(5, deliverables);
            ps.setInt(6, teamNumber);
            ps.setString(7, projectStatus);
            ps.setString(8, advisorID);
            ps.setString(9, mentorID);
            ps.setString(10,companyName);
            
            row = ps.executeUpdate();
        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            OracleConnection.closeConnection();
        }
        return row;    }
     
}
  

