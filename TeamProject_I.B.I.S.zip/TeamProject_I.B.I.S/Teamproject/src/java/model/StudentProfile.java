/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import util.OracleConnection;

/**
 *
 * @author Silvia Salazar
 */
public class StudentProfile {
  String studentId;
  String Fname;
  String Lname;
  String Academicyear;
  String Skills;
  String Experience;
  String Status;
  Connection conn = null;

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public String getAcademicyear() {
        return Academicyear;
    }

    public void setAcademicyear(String Academicyear) {
        this.Academicyear = Academicyear;
    }

    public String getSkills() {
        return Skills;
    }

    public void setSkills(String Skills) {
        this.Skills = Skills;
    }

    public String getExperience() {
        return Experience;
    }

    public void setExperience(String Experience) {
        this.Experience = Experience;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }
  
     public List<StudentProfile> getStudentProfile(){
        List<StudentProfile> student = new ArrayList<StudentProfile>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
    String sql = "select c.studentid, c.fname, c.lname, s.academicyear, s.skills, s.experience, s.status "
            + "from CSUstudent c, studentpublicprofile s where c.studentid = s.studentid";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        StudentProfile std = new StudentProfile();
        std.setStudentId (rs.getString("studentId"));
        std.setFname (rs.getString(2));
        std.setLname (rs.getString(3));
        std.setAcademicyear (rs.getString("academicYear"));
        std.setSkills (rs.getString(5));
        std.setExperience (rs.getString(6));
        std.setStatus (rs.getString(7));
        
        student.add(std);
    }
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return student;       
    }

  
  
}
