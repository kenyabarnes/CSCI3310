/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.*;
import java.util.*;
import util.OracleConnection;

/**
 *
 * @author baonl1957
 */
public class Students {
    String StudentID;
    String FName;
    String LName;
    String MName;
    String PhoneNumber;
    String Email; 
    String requestStatus; // 1 - yes; 0 - no
    int GroupNumber;
    String StuUserName;
    String StuPassWord;
    String DeptName;
    Connection conn = null;

    public String getStudentID() {
        return StudentID;
    }

    public void setStudentID(String StudentID) {
        this.StudentID = StudentID;
    }

    public String getFName() {
        return FName;
    }

    public void setFName(String FName) {
        this.FName = FName;
    }

    public String getLName() {
        return LName;
    }

    public void setLName(String LName) {
        this.LName = LName;
    }

    public String getMName() {
        return MName;
    }

    public void setMName(String MName) {
        this.MName = MName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getStuUserName() {
        return StuUserName;
    }

    public void setStuUserName(String StuUserName) {
        this.StuUserName = StuUserName;
    }

    public String getStuPassWord() {
        return StuPassWord;
    }

    public void setStuPassWord(String StuPassWord) {
        this.StuPassWord = StuPassWord;
    }

    public String getDeptName() {
        return DeptName;
    }

    public void setDeptName(String DeptName) {
        this.DeptName = DeptName;
    }

   

    public int getGroupNumber() {
        return GroupNumber;
    }

    public void setGroupNumber(int GroupNumber) {
        this.GroupNumber = GroupNumber;
    }

   

    public Connection getConn() {
        return conn;
    }

    public void setConn(Connection conn) {
        this.conn = conn;
    }
     public List<Students> getStudent(){
        List<Students> student = new ArrayList<Students>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
    String sql = "select * from CSUstudent";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        Students std = new Students();
        std.setStudentID (rs.getString("studentId"));
        std.setFName (rs.getString(2));
        std.setLName (rs.getString(3));
        std.setMName (rs.getString(4));
        std.setPhoneNumber (rs.getString(5));
        std.setEmail (rs.getString(6));
        std.setRequestStatus (rs.getString(7));
        std.setGroupNumber (rs.getInt(10));
        std.setDeptName (rs.getString(11));
        student.add(std);
    }
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return student;       
    }
     
      public List<Students> getAStudent(){
        List<Students> student = new ArrayList<Students>();
        
           try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
    String sql = "select * from CSUstudent where requestStatus = 'Approved'";
    ResultSet rs = stmt.executeQuery(sql);
    while (rs.next()){
        Students std = new Students();
        std.setStudentID (rs.getString("studentId"));
        std.setFName (rs.getString(2));
        std.setLName (rs.getString(3));
        std.setMName (rs.getString(4));
        std.setPhoneNumber (rs.getString(5));
        std.setEmail (rs.getString(6));
        std.setRequestStatus (rs.getString(7));
        std.setGroupNumber (rs.getInt(10));
        std.setDeptName (rs.getString(11));
        student.add(std);
    }
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    return student;       
    }
     
   public void updateStudent(String ID, String req){
    try{
    conn = OracleConnection.getConnection();
    Statement stmt = conn.createStatement();
    String sql = "UPDATE (select * from CSUStudent where studentID = ?)SET requestStatus = ?";
    PreparedStatement stmts = conn.prepareStatement(sql);
    stmts.setString(1, ID);
    stmts.setString(2, req);
    stmts.executeUpdate();
    
    }catch(Exception e){
    e.printStackTrace();
    
}finally{
    OracleConnection.closeConnection();        
        }
    }
}
