INSERT INTO csustaff VALUES 
('1004625714','Jean', 'May', 'Q', '4046899821',	'mayJ@clayton.edu',	'Graduated Student', 'hqow', '785rt', 'Health');

INSERT INTO CSUSTUDENT VALUES
('1004001568','Tim','Jane','Q','4041239874','JaneT@student.clayton.edu','Applied','tim8','123A',0,'Health');
INSERT INTO studentpublicprofile VALUES ('1004001568','2016','Power Point','No','Applied');
select * from csustaff;

INSERT INTO mentor VALUES
('1004625714','05/30/2017','ongoing');

INSERT INTO project VALUES
('101','Fast Reservation','Mobile Application','Health','ISO and Android',101,'Ongoing','1008001508','1004625714','ABC');